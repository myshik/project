<?php
#############################################################################
#  LegionStudio.NET
#  info@legionstudio.net
#############################################################################
// Heading 
$_['heading_title']  = 'Movie';
$_['youtube_extension']  = '&hl=en_US&fs=1&';
?>