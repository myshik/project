<?php

$_['waf_title'] = 'Additional info';

?>